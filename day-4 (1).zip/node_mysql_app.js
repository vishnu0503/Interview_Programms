const express = require('express')
const bodyPar = require('body-parser')
const mysql = require('mysql')

const app = express()
app.use(bodyPar.json())

app.listen(5000, () => console.log("listening to http://localhost:5000"))

var con = mysql.createConnection({
    user: 'root',
    password: 'root',
    database: 'productstore'
})

con.connect((err) => {
    if (err) throw err;
    console.log('connected to mysql db...')
})

app.get('/all', (req, res) => {
    let sql = `select *from products`
    con.query(sql, (err, products) => {

        if (err) throw err;
        res.send(products)
        res.end();
    })

})

app.post("/add", (req, res) => {
    let sql = `insert into products(name, price) values('${req.body.name}', ${req.body.price})`
    con.query(sql, (err, result) => {
        res.send('inserted...')
        res.end()
    })
})

app.put("/update/:id", (req, res) => {
    let sql = `update products set name='${req.body.name}', price=${req.body.price} 
    where id=${req.params.id}`
    con.query(sql, (err, result) => {
        if (err) throw err;
        res.send('updated...')
        res.end()
    })
})

app.delete('/del/:id', (req, res) => {
    let sql = `delete from products where id=${req.params.id}`
    con.query(sql, (err, result) => {
        if (err) throw err;
        res.send('deleted...')
        res.end()
    })
})