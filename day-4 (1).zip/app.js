var express = require('express')
var bp = require('body-parser')

var app = express()
app.use(bp.json())

app.listen(5000, () => console.log("browse using http://localhost:5000"))

let products = [
    { id: 1, name: 'television', price: 20000 },
    { id: 2, name: 'soap', price: 40 },
    { id: 3, name: 'laptop', price: 30000 }
]

app.get("/all", (req, res) => {
    console.log("GET...")
    res.send(products)
    res.end()
})

app.post("/add", (req, res) => {
    console.log(req.body)
    products.push(req.body)
    res.send(products)
    res.end();
})

app.put("/update/:id", (req, res) => {
    console.log("Product id: " + req.params.id)
    products.map((p) => {
        if (p.id == req.params.id) {
            p.name = req.body.name;
            p.price = req.body.price
        }
    })
    res.send(products)
    res.end()
})

app.delete("/del/:id", (req, res) => {
    console.log(`delete product ${req.params.id}`)
    products.map((p, i) => {
        if (p.id == req.params.id) {
            products.splice(i, 1)
        }
    })
    res.send(products)
    res.end()
})