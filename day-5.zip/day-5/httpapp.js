const http = require('http')

const server = http.createServer((req, res) => {
    res.write("hello, good morning...")
    res.end()
})

server.listen(4000, () => console.log('server running at http://localhost:4000'))
