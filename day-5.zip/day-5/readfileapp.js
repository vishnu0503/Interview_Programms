const fs = require('fs')

fs.readFile('D:/NGT/September/node/day_3_notes.txt', (err, data) => {
    if (err) throw err;
    console.log(data.toString())
})

