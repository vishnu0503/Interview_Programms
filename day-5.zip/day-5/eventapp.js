const fs = require('fs')
const events = require('events')
let ee = new events.EventEmitter()

ee.on('write', (data) => {
    fs.writeFile('test.txt', data, (err) => {
        if (err) throw err;
        console.log('file written successfully')
    })
})

ee.emit('write', "hello, good morning...")

ee.on('read', () => {
    fs.readFile('test.txt', (err, data) => {
        if (err) throw err;
        console.log(data.toString())
    })
})

setTimeout(() => ee.emit('read'), 5000)