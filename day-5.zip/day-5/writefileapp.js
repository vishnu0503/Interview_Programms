const fs = require('fs')

let content = " enjoy your day..."
fs.writeFile('sample.txt', content, { flag: 'a' }, (err) => {
    if (err) throw err;
    console.log('file written successfully')
})

