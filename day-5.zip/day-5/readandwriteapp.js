const fs = require('fs')
var content = '';
fs.readFile('D:/NGT/September/node/day_3_notes.txt', (err, data) => {
    if (err) throw err;
    content = data.toString();
    fs.writeFile("sample.txt", data.toString(), (err) => {
        if (err) throw err;
        console.log("file written...")
    })
})










